﻿Imports SAPbouiCOM.Framework
Imports SAPbobsCOM
Namespace E_Fakture
    Public Class Menu
        Private WithEvents SBO_Application As SAPbouiCOM.Application

        Sub New()
            SBO_Application = Application.SBO_Application
            LoadFromXML_Menu("Menus.xml")
            'LoadFromXML("Menus.xml")
        End Sub

       
        Private Sub LoadFromXML_Menu(ByVal FileName As String)
            Dim oXmlDoc As Xml.XmlDocument
            oXmlDoc = New Xml.XmlDocument
            Dim sPath As String
            sPath = System.Windows.Forms.Application.StartupPath
            oXmlDoc.Load(sPath & "\" & FileName)

            SBO_Application.LoadBatchActions(oXmlDoc.InnerXml)
            sPath = SBO_Application.GetLastBatchResults()

        End Sub

        Private Function LoadFromXML(ByVal FileName As String) As String

            Dim oXmlDoc As Xml.XmlDocument
            Dim sPath As String

            oXmlDoc = New Xml.XmlDocument

            sPath = System.Windows.Forms.Application.StartupPath

            oXmlDoc.Load(sPath & "\" & FileName)

            Return (oXmlDoc.InnerXml)

        End Function

        Protected Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub

        Private Sub SBO_Application_MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean) Handles SBO_Application.MenuEvent

        End Sub
    End Class
End Namespace