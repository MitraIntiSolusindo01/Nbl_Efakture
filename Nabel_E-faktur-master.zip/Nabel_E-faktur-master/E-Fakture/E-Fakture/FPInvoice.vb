﻿Imports SAPbouiCOM.Framework
Imports SAPbobsCOM
Imports System.IO

Namespace E_Fakture
    Public Class FPInvoice
        Private WithEvents SBO_Application As SAPbouiCOM.Application
        Public oCompany As SAPbobsCOM.Company

        Sub New()
            SBO_Application = Application.SBO_Application
            oCompany = Application.SBO_Application.Company.GetDICompany

        End Sub

        Private Function LoadFromXML(ByVal FileName As String) As String

            Dim oXmlDoc As Xml.XmlDocument
            Dim sPath As String

            oXmlDoc = New Xml.XmlDocument

            sPath = System.Windows.Forms.Application.StartupPath

            oXmlDoc.Load(sPath & "\" & FileName)

            Return (oXmlDoc.InnerXml)

        End Function

        Private Sub SBO_Application_ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean) Handles SBO_Application.ItemEvent
            On Error GoTo keluar
            AplicationItem(FormUID, pVal, BubbleEvent)
            'TSTPTAplicationItem(FormUID, pVal, BubbleEvent)
keluar:
        End Sub

        Private Sub SBO_Application_LayoutKeyEvent(ByRef eventInfo As SAPbouiCOM.LayoutKeyInfo, ByRef BubbleEvent As Boolean) Handles SBO_Application.LayoutKeyEvent

        End Sub
        Private Sub SBO_Application_MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean) Handles SBO_Application.MenuEvent
            If pVal.BeforeAction = False Then
                Select Case pVal.MenuUID
                    Case "Pajak_01"
                        Dim oForm As SAPbouiCOM.Form
                        Try
                            oForm = SBO_Application.Forms.Item("Pajak_01")
                            SBO_Application.MessageBox("Form Already Open")
                        Catch ex As Exception
                            LoadData("0", Nothing)
                        End Try
                End Select
            End If

            If pVal.BeforeAction = True Then
                Dim oForm As SAPbouiCOM.Form

                oForm = Application.SBO_Application.Forms.ActiveForm
             
                Select Case pVal.MenuUID
                    Case "1290" ' 1st Record
                    Case "1289" ' Prev Record
                    Case "1288" ' Next Record
                    Case "1291" ' Last Record
                    Case "1292" ' Add a row
                    Case "1293" ' Delete a row
                    Case "1282"
                End Select

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oForm)
                GC.Collect()

            End If
        End Sub

        Private Function ValidasiPajakKeluaran(ByVal stroption As String, ByVal oForm As SAPbouiCOM.Form) As Boolean
            ValidasiPajakKeluaran = True
            Dim strmasapajak As String = String.Empty

            strmasapajak = oForm.Items.Item("EdtFilter1").Specific.value
            If oForm.Items.Item("EdtFilter1").Specific.value = "" And ValidasiPajakKeluaran = True Then
                Application.SBO_Application.MessageBox("FP Date From must be fill", 1, "OK")
                oForm.Items.Item("EdtFilter1").Click()
                ValidasiPajakKeluaran = False
            End If

            If oForm.Items.Item("EdtFilter2").Specific.value = "" And ValidasiPajakKeluaran = True Then
                Application.SBO_Application.MessageBox("FP Date To must be fill", 1, "OK")
                oForm.Items.Item("EdtFilter2").Click()
                ValidasiPajakKeluaran = False
            End If

            If stroption = 1 Then
                If oForm.Items.Item("edtFlName").Specific.value = "" And ValidasiPajakKeluaran = True Then
                    Application.SBO_Application.MessageBox("File Name Must be fill", 1, "OK")
                    oForm.Items.Item("edtFlName").Click()
                    ValidasiPajakKeluaran = False
                End If
            End If
        End Function
       
        ''''****** Kodingan Untuk Load Data ke CSV Grid View ******
        Private Sub LoadData(ByVal stroption As String, Optional ByVal oForm As SAPbouiCOM.Form = Nothing)
            Dim InvQuery As String
            Dim oItem As SAPbouiCOM.Item
            Dim oEditText As SAPbouiCOM.EditText
            Dim oButton As SAPbouiCOM.Button
            Dim oColumn As SAPbouiCOM.EditTextColumn = Nothing
            Dim oColumn1 As SAPbouiCOM.EditTextColumn = Nothing
            Dim INVGrid As SAPbouiCOM.Grid
            Dim intcoloum As Integer
            Dim Count As Integer
            Dim introw As Integer
            Dim masapajak As String
            Dim Grid As SAPbouiCOM.Grid = Nothing
            Dim strDocument As String = ""

            If oForm Is Nothing Then
                Dim fcp As SAPbouiCOM.FormCreationParams
                fcp = Application.SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
                fcp.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
                fcp.FormType = "Pajak"
                fcp.UniqueID = "Pajak_01"

                fcp.XmlData = LoadFromXML("FPInvoce.srf")

                oForm = Application.SBO_Application.Forms.AddEx(fcp)

                oForm.ClientHeight = 522

                oForm.DataSources.DataTables.Add("Pajak")

                oForm.DataSources.UserDataSources.Add("Filter1", SAPbouiCOM.BoDataType.dt_DATE)
                oForm.DataSources.UserDataSources.Add("Filter2", SAPbouiCOM.BoDataType.dt_DATE)
                oForm.DataSources.UserDataSources.Add("Filter3", SAPbouiCOM.BoDataType.dt_LONG_TEXT)

                oForm.DataSources.UserDataSources.Add("option", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 1)
                oForm.DataSources.DataTables.Add("PajakGrid")

            End If

            oForm.DataSources.UserDataSources.Item("Filter1").Value = oForm.Items.Item("EdtFilter1").Specific.string
            oForm.DataSources.UserDataSources.Item("Filter2").Value = oForm.Items.Item("EdtFilter2").Specific.string
            oForm.DataSources.UserDataSources.Item("Filter3").Value = oForm.Items.Item("EdtFilter3").Specific.string

            oForm.Items.Item("optExp").Specific.databind.setbound(True, "", "option")
            oForm.Items.Item("optReExp").Specific.GroupWith("optExp")

            oEditText = oForm.Items.Item("EdtFilter1").Specific
            oEditText.DataBind.SetBound(True, "", "Filter1")
            oEditText = oForm.Items.Item("EdtFilter2").Specific
            oEditText.DataBind.SetBound(True, "", "Filter2")
            oEditText = oForm.Items.Item("EdtFilter3").Specific
            oEditText.DataBind.SetBound(True, "", "Filter3")
            oForm.Freeze(True)

            INVGrid = oForm.Items.Item("Grid").Specific
            INVGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Auto

            Dim strfilter1 As String = String.Empty
            Dim strfilter2 As String = String.Empty
            Dim strfilter3 As String = String.Empty
            Dim strfilter4 As String = String.Empty
            Dim strfilter5 As String = String.Empty
            Dim strReprint As String = String.Empty

            strfilter1 = oForm.Items.Item("EdtFilter1").Specific.value
            strfilter2 = oForm.Items.Item("EdtFilter2").Specific.value
            strfilter3 = oForm.Items.Item("EdtFilter3").Specific.value

            If stroption = 0 Then
                oForm.Items.Item("optExp").Specific.Selected = True
            End If

            If oForm.Items.Item("optExp").Specific.Selected = True Then
                strReprint = 0
            Else
                strReprint = 1
            End If


            If stroption = 0 Then
                InvQuery = "Exec [MIS_Load_OINV] '" & strfilter1 & "', '" & strfilter2 & "','Invoice','" & strReprint & "'"
            Else
                InvQuery = "Exec [MIS_Load_OINV] '" & strfilter1 & "', '" & strfilter2 & "','" & strfilter3 & "','" & strReprint & "'"
            End If

            ' Grid #: 1
            oForm.DataSources.DataTables.Item("PajakGrid").ExecuteQuery(InvQuery)
            INVGrid.DataTable = oForm.DataSources.DataTables.Item("PajakGrid")

            intcoloum = INVGrid.DataTable.Columns.Count
            introw = INVGrid.DataTable.Rows.Count

            INVGrid.Columns.Item(0).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox

        
            oColumn = INVGrid.Columns.Item(1)
            oColumn.LinkedObjectType = SAPbouiCOM.BoLinkedObject.lf_Invoice
            Grid = oForm.Items.Item("Grid").Specific



            Dim i As Integer
            For i = 0 To Grid.Rows.Count - 1
                If Grid.DataTable.GetValue(("Document"), i).ToString = "Invoice" Then
                    INVGrid.Columns.Item(1).TitleObject.Sortable = True
                    oColumn.Editable = False
                    INVGrid.Columns.Item(1).Width = 30
                ElseIf Grid.DataTable.GetValue(("Document"), i).ToString = "Good Issue" Then
                    INVGrid.Columns.Item(2).TitleObject.Sortable = True
                    oColumn1.Editable = False
                    INVGrid.Columns.Item(2).Width = 30
                End If
            Next

            INVGrid.Columns.Item(Count).RightJustified = True
            For Count = 2 To intcoloum - 1
                INVGrid.Columns.Item(Count).Type = SAPbouiCOM.BoGridColumnType.gct_EditText
                INVGrid.Columns.Item(Count).TitleObject.Sortable = True
                INVGrid.Columns.Item(Count).Editable = False

            Next

            masapajak = oForm.Items.Item("EdtFilter1").Specific.value.ToString.Trim
            If introw = 1 And INVGrid.DataTable.GetValue(("FP No"), 0).ToString.Trim = "" And masapajak <> "" Then
                Application.SBO_Application.MessageBox("Data Not Found", 1, "OK")
            End If

            INVGrid.AutoResizeColumns()
            oForm.Freeze(False)

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oForm)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oEditText)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(INVGrid)

            oEditText = Nothing
            oItem = Nothing
            oButton = Nothing
            INVGrid = Nothing
            GC.Collect()

            'End Try
        End Sub

        ''''****** Kodingan Untuk Export Data ke CSV ******
        Private Sub ExportData(ByVal oForm As SAPbouiCOM.Form, ByVal strfilename As String, ByVal strconnection As String, ByVal strPathDestination As String)
            On Error GoTo ErrorHandler
            Dim objRecSet As SAPbobsCOM.Recordset = Nothing
            Dim objRecSet2 As SAPbobsCOM.Recordset = Nothing
            objRecSet = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            objRecSet2 = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim Grid As SAPbouiCOM.Grid = Nothing
            Dim strSQL As String
            Dim strSQL2 As String
            Dim strNoPajak As String = ""
            Dim strPath As String
            Dim strDocument As String = ""

            Grid = oForm.Items.Item("Grid").Specific
            Dim i As Integer
            For i = 0 To Grid.Rows.Count - 1
                If Grid.DataTable.GetValue(("Select All"), i) = "Y" Then
                    If strNoPajak <> "" Then
                        strNoPajak = strNoPajak + ","
                        strDocument = Grid.DataTable.GetValue(("Document"), i).ToString
                    End If
                    strNoPajak = strNoPajak + "'" + Grid.DataTable.GetValue(("FP No"), i).ToString + "'"
                    strDocument = Grid.DataTable.GetValue(("Document"), i).ToString
                End If
            Next

            If strNoPajak <> "" Then
                If strDocument = "Invoice" Then
                    strSQL = " select * from OINV_PajakDetail  " & _
                             " where U_MIS_FPNum in (" + strNoPajak + ") OR U_MIS_FPNum='0' order by U_MIS_FPNum,SORT "
                    objRecSet.DoQuery(strSQL)

                ElseIf strDocument = "Down Payment" Then
                    strSQL = " select * from ODPI_PajakDetail  " & _
                             " where U_MIS_FPNum in (" + strNoPajak + ") or U_MIS_FPNum='0'  order by U_MIS_FPNum,SORT "
                    objRecSet.DoQuery(strSQL)
                End If

                If objRecSet.RecordCount > 0 Then

                    Dim CsvText As String = String.Empty
                    Dim temp As String
                    objRecSet.MoveFirst()
                    For row = 0 To objRecSet.RecordCount - 1
                        temp = Replace(objRecSet.Fields.Item(2).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(3).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(4).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(5).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(6).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(7).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(8).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(9).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(10).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(11).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(12).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(13).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(14).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(15).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(16).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(17).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(18).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(19).Value.ToString, ",", " ") + "," + _
                                Replace(objRecSet.Fields.Item(20).Value.ToString, ",", " ") + ","
                        CsvText = CsvText + temp + vbCr & vbLf
                        objRecSet.MoveNext()
                    Next

                    strSQL2 = "SELECT ExcelPath [Path] FROM OADM"
                    objRecSet2.DoQuery(strSQL2)
                    strPath = objRecSet2.Fields.Item("Path").Value.ToString

                    strfilename = strPath + oForm.Items.Item("edtFlName").Specific.value.ToString.Trim + ".CSV"

                    Dim myWriter As New StreamWriter(strfilename)
                    myWriter.Write(CsvText)
                    myWriter.Flush()
                    myWriter.Close()

                    If strDocument = "Invoice" Then
                        strSQL = "Update OINV_PajakUpdate Set U_MIS_Export=isnull(U_MIS_Export,0)+1 " & _
                             " where U_MIS_FPNum in (" + strNoPajak + ")"
                        objRecSet.DoQuery(strSQL)

                        SBO_Application.MessageBox("Export Data Success..!", 1, "OK")
                        LoadData("1", oForm)

                    ElseIf strDocument = "Down Payment" Then
                        strSQL = "Update ODPI_PajakUpdate Set U_MIS_Export=isnull(U_MIS_Export,0)+1 " & _
                             " where U_MIS_FPNum in (" + strNoPajak + ")"
                        objRecSet.DoQuery(strSQL)


                        SBO_Application.MessageBox("Export Data Success..!", 1, "OK")
                        LoadData("1", oForm)


                        oForm.Items.Item("edtFlName").Specific.value = ""
                    Else
                        SBO_Application.MessageBox("Data Not Found..!", 1, "OK")
                        LoadData("1", oForm)

                    End If
                Else

                    SBO_Application.MessageBox("Please Select Data..!", 1, "OK")
                End If

            End If

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oForm)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(Grid)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(objRecSet)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(objRecSet2)

            objRecSet = Nothing
            objRecSet2 = Nothing
            Grid = Nothing

            Exit Sub
ErrorHandler:

            LoadData("1", oForm)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oForm)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(Grid)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(objRecSet)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(objRecSet2)
            objRecSet = Nothing
            objRecSet2 = Nothing
            Grid = Nothing

            If Err.Description <> "" Then
                SBO_Application.MessageBox("Exception: " & Err.Description, 1, "OK")
            End If
        End Sub

#Region "Aplication Event"
        Private Sub AplicationItem(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
            If pVal.ActionSuccess = True Then
                If pVal.FormTypeEx = "Pajak" Then
                    Dim oForm As SAPbouiCOM.Form = Nothing
                    If pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_CLOSE And pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE And pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_UNLOAD Then
                        oForm = Application.SBO_Application.Forms.Item(pVal.FormUID)
                    End If
                End If
            End If
            If pVal.Before_Action = True Then
                If pVal.FormTypeEx = "Pajak" Then
                    Dim oForm As SAPbouiCOM.Form = Nothing
                    If pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_CLOSE And pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_DEACTIVATE And pVal.EventType <> SAPbouiCOM.BoEventTypes.et_FORM_UNLOAD Then
                        oForm = SBO_Application.Forms.Item(pVal.FormUID)
                    End If

                    Select Case pVal.EventType
                        Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                            If pVal.ItemUID = "btnSearch" Then
                                oForm = Application.SBO_Application.Forms.Item(FormUID)
                                If ValidasiPajakKeluaran("0", oForm) = True Then
                                    LoadData("1", oForm)
                                End If
                            ElseIf pVal.ItemUID = "btnGen" Then
                                oForm = Application.SBO_Application.Forms.Item(FormUID)
                                Dim stroption As Integer
                                stroption = Application.SBO_Application.MessageBox("Data Akan Di Export...!", 2, "Yes", "No")

                                If stroption = 1 Then
                                    If BubbleEvent = True Then
                                        If ValidasiPajakKeluaran("1", oForm) = True Then
                                            ExportData(oForm, "", "", "")
                                        End If
                                    End If
                                End If
                            End If

                        Case SAPbouiCOM.BoEventTypes.et_CLICK
                            If (pVal.ColUID = "Select All") And pVal.Row = -1 Then
                                Dim PdcGrid As SAPbouiCOM.Grid = Nothing
                                Dim i As Integer
                                oForm.Freeze(True)
                                PdcGrid = oForm.Items.Item("Grid").Specific

                                If PdcGrid.Columns.Item("Select All").Editable = True Then
                                    If PdcGrid.Columns.Item("Select All").TitleObject.Caption = "Select All" Then
                                        For i = 0 To PdcGrid.Rows.Count - 1
                                            PdcGrid.DataTable.SetValue("Select All", i, "Y")
                                        Next
                                        PdcGrid.Columns.Item("Select All").TitleObject.Caption = "Reset All"
                                    Else
                                        For i = 0 To PdcGrid.Rows.Count - 1
                                            PdcGrid.DataTable.SetValue("Select All", i, "N")
                                        Next
                                        PdcGrid.Columns.Item("Select All").TitleObject.Caption = "Select All"
                                    End If
                                End If
                                oForm.Freeze(False)
                                PdcGrid = Nothing
                            End If
                    End Select
                End If
            End If
        End Sub
#End Region
    End Class
End Namespace
